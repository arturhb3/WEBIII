package ifpr.formularioprojeto4.controllers;

import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


import ifpr.formularioprojeto4.models.Formulario;
import ifpr.formularioprojeto4.services.FormularioServices;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class FomularioServlet extends HttpServlet {
    private String message;

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {

        Formulario formulario= new  Formulario();
        FormularioServices service= new FormularioServices();

        String texto= null;
        try {
            texto = service.validaTexto(request.getParameter("campo_texto"));
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
        formulario.setTexto(texto);

        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        System.out.println("Chamou a servlet.");

        texto=request.getParameter("campo_texto");
        System.out.println("O valor informado foi: "+texto);

        if(request.getParameter("campo_numerioco")!=null && !request.getParameter("campo_numerico").isBlank()){

            Integer numero = Integer.parseInt(request.getParameter("campo_numerico"));
            System.out.println("O numero informado foi:" + numero);
        }

        String dataTexto = request.getParameter("campo_data");
        LocalDate data= LocalDate.parse(dataTexto);

        System.out.println("a data enviada foi: "+data.format(formato));

        String opcao=request.getParameter("campo_opcoes");
        System.out.println("A opção escolhida foi: "+opcao);

        String[] herois = request.getParameterValues("campo_checkbox");
        System.out.println("O(s) herioi(s) selecionado(s) foi(ram): ");
        for(String heroi:herois){
            System.out.println(heroi);
        }

        response.sendRedirect(request.getContextPath());
    }

    public void destroy() {
    }
}