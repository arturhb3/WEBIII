package ifpr.formularioprojeto4.services;

public class FormularioServices {

    public  String validaTexto(String text) throws IllegalAccessException {

        if(text==null || text.isEmpty() || text.length()<2){
            throw new IllegalAccessException("Valor informado é invalido!!");
        }
        return text.trim();
    }


}
