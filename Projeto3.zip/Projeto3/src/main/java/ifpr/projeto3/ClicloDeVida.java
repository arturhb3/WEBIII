package ifpr.projeto3;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@WebServlet("/ciclo_de_vida")
public class ClicloDeVida extends HttpServlet {
    int contagem;
    @Override
    public void init() throws ServletException {
        System.out.println("Passou pelo init");
    }

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        System.out.println("Passou pelo service");
        contagem++;
        System.out.println("O usuario acessou o service:"+contagem);
    }

    @Override
    public void destroy() {
        System.out.println("Passou pelo destroy");
    }
}
